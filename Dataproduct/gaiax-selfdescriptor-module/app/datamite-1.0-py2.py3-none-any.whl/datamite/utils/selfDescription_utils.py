"""
MIT License

Copyright (c) 2024 Tecnalia, Basque Research & Technology Alliance (BRTA)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

"""This module give the functionality to work with Gaia-X self descriptions
"""

import hashlib
import json
import logging
import os
import re
import time
import uuid
from datetime import datetime

import requests
import validators

from datamite.models.dataProductResourcesBody import DataProductResourcesModel
from datamite.models.dataResourceModel import GxProducedBy, GxExposedThrough, CredentialSubjectDR, DataResourceModel
from datamite.models.legalParticipantBodyModel import LegalParticipantBodyModel
from datamite.models.legalParticipantModel import GxLegalRegistrationNumber, GxHeadquarterAddress, GxLegalAddress, \
    CredentialSubjectLP, LegalParticipantModel
from datamite.models.legalRegistrationModel import LR_VatIDModel, LR_LeicodeModel, LR_EORIModel
from datamite.models.serviceOfferingModel import GxTermsAndConditions, GxDataAccountExportItem, GxProvidedBy, \
    CredentialSubjectSO, ServiceOffering, GxAggregationOfItem, ServiceOfferingSAP, \
    CredentialSubjectSAP
from datamite.models.termAndCondModel import CredentialSubject, TermsAndConditionsModel
from datamite.utils.certificate_utils import get_infoFromURL
from datamite.utils.certificate_utils import sign_doc
from datamite.utils.did_utils import generateDid
from datamite.utils.gaiax_utils import callCompliance, callCredentialsEventService
from datamite.utils.neo4j_utils import loadInNeo4j
from datamite.utils.postgres_utils import insertData
from datamite.utils.postgres_utils import insertDatProduct
from datamite.utils.postgres_utils import checkDataProduct

logger = logging.getLogger("uvicorn.error")



#Get the current datatime in ISO format
def getCurrentDateTimeInISO():


    """
       Get the current data time in ISO format

       :return: current data time in iso format
       :rtype: str

    """

    logger.debug("getCurrentDateTimeInISO init")
    current_date = datetime.now()
    return current_date.isoformat()

#Check if a domain is valid
def isValidDomain(domain):

    """
       Check if the domain is valid

       :param domain: domain to be checked
       :return: true/false if the domain is valid or not
       :rtype: bool

    """


    logger.debug("isValidDomain init")
    # Regex to check valid
    # domain name.
    regex = "^((?!-)[A-Za-z0-9-]" + "{1,63}(?<!-)\\.)" + "+[A-Za-z]{2,6}"

    # Compile the ReGex
    p = re.compile(regex)

    # If the string is empty
    # return false
    if (domain == None):
        return False

    # Return if the string
    # matched the ReGex
    if (re.search(p, domain)):
        return True
    else:
        return False

#check is an URL is valid
def isValidURL(url):

    """
       Check if the URL is valid

       :param url: url to be checked
       :return: true/false if the domain is valid or not
       :rtype: bool

    """

    logger.debug("isValidURL init")
    if url is not None:

        if validators.url(url) is not None:
            return True
        else:
            return False
    return True

#check is an URL is valid and resolvable
def isCompleteValidURL(url):
    """
       Check if the URL is complete

       :param url: url to be checked
       :return: true/false if the domain is valid or not
       :rtype: bool

    """

    logger.debug("isCompleteValidURL starts")
    if str is not None:

        if validators.url(url) and get_infoFromURL(url) is not None:
            return True
        else:
            return False
    return True

#check if the ISOCode is correct
def checkISOCode(code):
    """
        Check if the isoCodel is valid

        :param code: isocode to be checked
        :return: true/false if the domain is valid or not
        :rtype: bool

     """

    logger.debug("checkISOCode starting")
    response= get_infoFromURL(os.getenv("ISO_CODES_URL")+str(code))
    if response is None:
        return False
    else:
        return True


# Method for creating a Gaia-X Legal Participant
#it is formed by legalRegistrationNumber self-description + Terms and Conditions self-description and
# its legalParticipant self-description
def generateCompleteLegalPerson(body:LegalParticipantBodyModel, compliance:bool):


    """
        Generate a complete Legal Person self-description

        :param body: json format information as input
        :param compliance: boolean property true/false
        :return: JSON that presents a complete LegalPerson self-description
        :rtype: str

     """


    logger.debug("generateCompleteLegalPerson SD")
    claims=[]
    if compliance==True and os.getenv("PRIVATE_KEY") is None:
        return "You should include a value for privateKey"
    else:

        # Generate Legal Registration Number
        logger.debug("Generate Legal Registration Number")
        docLRN = build_legal_registration_number_vc(body.domain, body.legalRegistrationType,
                                                                   body.legalRegistrationNumber)
        logger.debug(f"Generate Legal Registration Number={docLRN}")
        claims.append(docLRN)
        try:
            if docLRN["type"]:
                # Generate Terms and Conditions
                logger.debug("Generation TC SD")
                docTC = build_terms_conditions_vc(body.domain, compliance)
                logger.debug (f"Terms and conditions self={docTC}")
                #append self-description to be signed after if compliance==true
                claims.append(docTC)
                #Generate Legal Person
                logger.debug("Generation LP SD")
                docLP = build_legal_person_vc(body.domain, body.participantURL, body.legalName, body.headquarterAddress, body.legalAddress,
                                                    compliance)
                # append self-description to be signed after if compliance==true
                logger.debug (f"Legal Participant self-desc ={docLP}")
                claims.append(docLP)

                # Generate complete VP for Legal Person+ Term&Conditions+Legal Registration Number
                fileName=body.participantURL.replace(os.getenv("PROTOCOL") + str(body.domain) + str(os.getenv("FOLDER")),"")

                #save LegalParticipantVerifiablePresentation to file
                fileNamePath = os.getenv("GAIAX_SD_FOLDER") + fileName
                with open(fileNamePath, "w") as f:
                    json.dump(createVpParticipant(claims), f)

                return createVpParticipant(claims)

        except:
            return "Error generating Legal Person Verifiable Presentation"



def build_terms_conditions_vc(domain: str, compliance:bool):
    """
          Generate a terms and conditions verifiable credential in Json format

          :param domain: domain  as input
          :param compliance: boolean property true/false
          :return: JSON that presents a terms and conditions verifiable credential
          :rtype: str

       """


    logger.debug("build_terms_conditions_vc init")
    urlTermsAndConditions = os.getenv("PROTOCOL") + str(domain) + str(os.getenv("FOLDER")) + str(os.getenv("TC_URL_END"))

    termsAndConditions = os.getenv("TERMS_AND_CONDITIONS_TEXT")

    didId = "did:web:"+str(domain)
    cxt = os.getenv("CONTEXT_TC")
    cs=CredentialSubject(context=cxt,type="gx:GaiaXTermsAndConditions",id=urlTermsAndConditions,gx_termsAndConditions=termsAndConditions)

    cxtList=getContextList()

    tc = TermsAndConditionsModel(context=cxtList, type="VerifiableCredential", id=urlTermsAndConditions,
                                     issuer=didId,
                                     issuanceDate=getCurrentDateTimeInISO(), credentialSubject=cs)


    logger.debug(f"terms and conditions self-desc={tc.model_dump(by_alias=True)}")
    fileNamePath = os.getenv("GAIAX_SD_FOLDER") + os.getenv("TC_URL_END")

    logger.debug("build_terms_conditions_vc()::signClaim init")
    claim = signClaim(compliance, fileNamePath, domain, tc.model_dump(by_alias=True))

    logger.debug(claim)
    return claim



def build_legal_person_vc(domain:str,participantURL:str,legName:str, headquarterAddress:str,legalAddress:str,compliance:bool):

    """
          Generate a legal person verifiable credential in Json format

          :param domain: domain  as input
          :param participantURL: participant complete URL
          :param legName: legal Name for the Legal Person
          :param headquarterAddress: headquarter Address
          :param legalAddress: legalAddress value
           :param compliance: boolean property true/false
          :return: JSON that presents a terms and conditions verifiable credential
          :rtype: str

       """

    logger.debug("build_legal_person_vc init")

    urlTermsAndConditions = os.getenv("PROTOCOL") + str(domain) + str(os.getenv("FOLDER")) + str(
        os.getenv("TC_URL_END"))
    urlLRN = os.getenv("PROTOCOL") + str(domain) + str(os.getenv("FOLDER")) + str(os.getenv("RN_URL_END"))
    didId = "did:web:" + str(domain)

    cxtList=getContextList()

    lrn=GxLegalRegistrationNumber(id=urlLRN)
    hqa=GxHeadquarterAddress(gx_countrySubdivisionCode=headquarterAddress)
    la=GxLegalAddress(gx_countrySubdivisionCode=legalAddress)




    cs = CredentialSubjectLP(id=participantURL, type="gx:LegalParticipant", legalName=legName,gx_legalRegistrationNumber=lrn.model_dump(mode='json'),gx_headquarterAddress=hqa.model_dump(mode='json'),gx_legalAddress=la.model_dump(mode='json'),gx_terms_and_conditions_gaiaxTermsAndConditions=urlTermsAndConditions)

    typeList=[]
    typeList.append("VerifiableCredential")


    lp = LegalParticipantModel(context=cxtList, type=typeList, id=participantURL, issuer=didId,
                                   issuanceDate=getCurrentDateTimeInISO(), credentialSubject=cs)

    logger.debug(f":legal person vc self-desc={lp.model_dump(by_alias=True)}")

    fileNamePath = os.getenv("GAIAX_SD_FOLDER") + os.getenv("PARTICIPANT_END")

    claim = signClaim(compliance, fileNamePath, domain, lp.model_dump(by_alias=True))
    return claim




def build_legal_registration_number_vc(domain:str, legalRegistrationType:str, legalRegistrationNumber: str):

    """
          Generate a legal registration number for production verifiable credential in Json format

          :param domain: domain  as input
          :param legalRegistrationType: legalRegistrationType parameter
          :param legalRegistrationNumber: legalRegistrationNumber parameter
          :return: JSON that presents a Legal registration number verifiable credential
          :rtype: str

       """



    logger.debug("build_legal_registration_number_vc init")
    #Generate complete URL for the LegalRegistrationNumber self-description
    urlLRN = os.getenv("PROTOCOL") + str(domain) + str(os.getenv("FOLDER")) + str(os.getenv("RN_URL_END"))


    #Preparate the input json for calling to Gaia-X NOTARIZATION_API
    contextList=[]
    contextList.append(os.getenv("CONTEXT_LRN"))
    if legalRegistrationType=='vatID':
        logger.debug("vatID")
        selfDescription=LR_VatIDModel(context=contextList,type="gx:legalRegistrationNumber",id=urlLRN,gx_vatID=legalRegistrationNumber)
    elif legalRegistrationType=='leiCode':
        logger.debug("leiCode")
        selfDescription=LR_LeicodeModel(context=contextList,type="gx:legalRegistrationNumber",id=urlLRN,gx_leiCode=legalRegistrationNumber)
    else:
        logger.debug("EORI")
        selfDescription = LR_EORIModel(context=contextList, type="gx:legalRegistrationNumber", id=urlLRN,
                                          gx_eori=legalRegistrationNumber)

    #make request to NOTARIZATION_API
    logger.debug("request Notarization API")
    response = requests.request("POST", os.getenv("NOTARIZATION_API"), json=selfDescription.model_dump(by_alias=True))
    logger.debug(f"response Notarization API={response.status_code}")
    if response.status_code == 200:
       fileNamePath = os.getenv("GAIAX_SD_FOLDER") + os.getenv("RN_URL_END")
       with open(fileNamePath, "w") as f:
            json.dump(response.json(), f)
    #output from NOTARIZATION_API, JSON FILE WITH LEGAL REGISTRATION NUMBER SELF-DESCRIPTION
    return response.json()



def build_legal_registration_number_vc_development(domain:str, legalRegistrationType:str, legalRegistrationNumber: str):


    """
          Generate a legal registration number for development verifiable credential in Json format

          :param domain: domain  as input
          :param legalRegistrationType: legalRegistrationType parameter
          :param legalRegistrationNumber: legalRegistrationNumber parameter
          :return: JSON that presents a Legal registration number verifiable credential
          :rtype: str

       """

    logger.debug("build_legal_registration_number_vc init")
    #Generate complete URL for the LegalRegistrationNumber self-description
    urlLRN = os.getenv("PROTOCOL") + str(domain) + str(os.getenv("FOLDER")) + str(os.getenv("RN_URL_END"))


    #Preparate the input json for calling to Gaia-X NOTARIZATION_API
    contextList=[]
    contextList.append(os.getenv("CONTEXT_LRN"))
    if legalRegistrationType=='vatID':
        logger.debug("vatID")
        logger.debug("request Notarization API")
        logger.debug(os.getenv("NOTARIZATION_API"))
        url_notarization=os.getenv("NOTARIZATION_API")+"vat-id"+"/"+legalRegistrationNumber+"?vcId="+urlLRN+"&subjectId="+urlLRN
        logger.debug(url_notarization)


    elif legalRegistrationType=='leiCode':
        logger.debug("leiCode")
        url_notarization = os.getenv(
            "NOTARIZATION_API") + "leiCode" + "/" + legalRegistrationNumber + "?vcId=" + urlLRN + "&subjectId=" + urlLRN

    elif legalRegistrationType == 'EORI':
        logger.debug("EORI")
        url_notarization = os.getenv(
            "NOTARIZATION_API") + "eori" + "/" + legalRegistrationNumber + "?vcId=" + urlLRN + "&subjectId=" + urlLRN

    else:
        logger.debug("taxID")
        url_notarization = os.getenv(
            "NOTARIZATION_API") + "taxId" + "/" + legalRegistrationNumber + "?vcId=" + urlLRN + "&subjectId=" + urlLRN


    #make request to NOTARIZATION_API
    logger.debug("request Notarization API")
    response = requests.request("GET", url_notarization)
    logger.debug(f"response Notarization API={response.status_code}")
    if response.status_code == 200:
       fileNamePath = os.getenv("GAIAX_SD_FOLDER") + os.getenv("RN_URL_END")
       with open(fileNamePath, "w") as f:
            json.dump(response.json(), f)
    #output from NOTARIZATION_API, JSON FILE WITH LEGAL REGISTRATION NUMBER SELF-DESCRIPTION
    return response.json()





#generate DataAccoutExport items
def generateDataAccountExport(dataAccount:str):

    """
          Generate a DataAccount part for the DataProduct service offering

          :param dataAccount: data account information as input
          :return: JSON that presents a DataAccount information
          :rtype: str

       """


    logger.debug("generateDataAccountExport init")

    logger.debug (dataAccount)
    logger.debug (dataAccount.__len__())
    listDAE=[]
    for item in dataAccount:
        logger.debug(item)

        gxdaExp=GxDataAccountExportItem(gx_requestType=item.requestType,gx_accessType=item.accessType,gx_formatType=item.formatType)
        listDAE.append(gxdaExp)
    logger.debug("generateDataAccountExport end")

    return listDAE





"""
def generate_service_offering(body:DataProductBodyModel,compliance:bool):

    logger.debug("generate_service_offering init")
    didId = os.getenv("DID") + str(body.domain)
    str_uuid=uuid.uuid4()

    serviceOfferingId = os.getenv("PROTOCOL") + str(body.domain) + str(os.getenv("FOLDER")) +str(str_uuid) +str(os.getenv("FILE_END"))
    logger.debug(f"service offering id={serviceOfferingId}")

    logger.debug(f"requesting participant URL={body.participantURL}")

    participantSD=requests.request("get",body.participantURL).json()

    logger.debug(f"particiant SD={participantSD}")

    cxtList=getContextList()

    gxTC=GxTermsAndConditions(gx_URL=body.dataProductTC,gx_hash=encrypt_string(body.dataProductTC))

    listDAE=generateDataAccountExport(body.dataAccount)
    logger.debug(
        f"DataAcount export list={listDAE}")



    provided=GxProvidedBy(id=body.participantURL)

    cs=CredentialSubjectSOWithoutResources(gx_name=body.dataProductName,gx_description=body.dataProductDesc,type="gx:ServiceOffering",gx_providedBy=provided.model_dump(mode='json'),gx_policy=body.dataProductPolicy,gx_termsAndConditions=gxTC.model_dump(mode='json'),gx_dataAccountExport=listDAE,id=serviceOfferingId)

    so = ServiceOfferingWithoutResources(context=cxtList, type="VerifiableCredential", id=serviceOfferingId,
                                         issuer=didId, issuanceDate=getCurrentDateTimeInISO(), credentialSubject=cs)

    logger.debug(f"Service offering SD={so.model_dump(by_alias=True)}")


    fileNamePath = os.getenv("GAIAX_SD_FOLDER") + str("serviceOffering_")+str(str_uuid)+str(".json")
    claims = []
    if compliance == True:
        so=sign_doc(so.model_dump(by_alias=True), str(didId) + os.getenv("ISSUER_KEY"))
        with open(fileNamePath, "w") as f:

            json.dump(so, f)
        claims.append(so)

    else:
        with open(fileNamePath, "w") as f:

            json.dump(so.model_dump(by_alias=True), f)
        claims.append(so.model_dump(by_alias=True))

    logger.debug(f"Pushing participant SD to other claims")
    sd=pushVcToParticipant(participantSD,claims)
    logger.debug(f"Pushed participant SD to other claims")

    fileNamePath = os.getenv("GAIAX_SD_FOLDER") + str("vp_serviceOffering_") + str(str_uuid) + str(os.getenv("FILE_END"))
    with open(fileNamePath, "w") as f:
        json.dump(sd, f)

    return sd



"""

def generateDataresourcesSelfDescription(serviceOfferingId:str,dataResourceURL:str,dataresource:str, didId:str,participantURL:str,dataResourcePolicy:str):

    """
          Generate a DataResouces self-description that is part for the DataProduct service offering

          :param serviceOfferingId: data product id
          :param dataResourceURL: URL for the created dataresource URL
          :param dataresource: information for the dataresource
          :param didId: decentralized identifier
          :param participantURL: url of the participant
          :param dataResourcePolicy: policy for the dataresource
          :return: JSON that presents a DataResource  information
          :rtype: str

       """




    logger.debug("generateDataresourcesSelfDescription init")
    prodBy=GxProducedBy(id=participantURL)
    exposedT=GxExposedThrough(id=serviceOfferingId)
    logger.debug (dataresource)

    #quality=dataResourcePolicy


    cs=CredentialSubjectDR(gx_name=dataresource.name, gx_description=dataresource.description,type="gx:DataResource",
        gx_containsPII=False,gx_policy=dataResourcePolicy, gx_license=dataresource.license, gx_copyrightOwnedBy=dataresource.copyrightOwnedBy,
        gx_producedBy=prodBy.model_dump(mode='json'),gx_exposedThrough=exposedT.model_dump(mode='json'), id=dataResourceURL)





    cxtList=getContextList()
    dr = DataResourceModel(context=cxtList, type="VerifiableCredential", id=dataResourceURL, issuer=didId,
                             issuanceDate=getCurrentDateTimeInISO(),
                             credentialSubject=cs)

    logger.debug(f"data resouurce SD={dr.model_dump(by_alias=True)}")

    return dr



"""
def generateServiceAccessPoint(dataresource:str,serviceAccessPointURL:str,didId:str):

    logger.debug("generateServiceAccessPoint init")
    cs = CredentialSubjectAccessPoint(type="gx:ServiceAccessPoint",gx_host=dataresource.host,gx_port=dataresource.port,gx_protocol=dataresource.protocol,
    gx_version=dataresource.version,gx_openAPI=dataresource.openAPIURL,id=serviceAccessPointURL)


    cxtList=getContextList()
    so = ServiceAccessPointModel(context=cxtList, type="VerifiableCredential", id=serviceAccessPointURL, issuer=didId,
                          issuanceDate=getCurrentDateTimeInISO(), credentialSubject=cs)

    logger.debug(f"Sservice access point SD={so.model_dump(by_alias=True)}")

    return so


"""

def generateServiceAccessPointService(dataresource:str,serviceAccessPointURL:str,didId:str,participantURL:str,servicePolicy:str,serviceTC:str, dataAccount:str):
    """
          Generate a ServiceAccessPoint service offering self-description that is part for the DataProduct service offering
          :param dataresource: information for the dataresource URL
          :param serviceAccessPointURL: URL for the service access point URL
          :param didId: decentralized identifier
          :param participantURL: url of the participant
          :param servicePolicy: policy for the service
          :param serviceTC: service terms and conditions
          :param dataAccount: dataAccount information
          :return: JSON that presents a Service access point  information
          :rtype: str

       """


    logger.debug("generateServiceAccessPointService init")

    """logger.debug (dataresource.host)
    logger.debug (dataresource.port)
    logger.debug(dataresource.protocol)"""
    logger.debug(dataresource.openAPIURL)



    cxtList=getContextList()

    gxTC = GxTermsAndConditions(gx_URL=serviceTC, gx_hash=encrypt_string(serviceTC))

    listDAE = generateDataAccountExport(dataAccount)
    logger.debug(listDAE)

    provided = GxProvidedBy(id=participantURL)


    cs = CredentialSubjectSAP(type="gx:ServiceOffering",
                          gx_providedBy=provided.model_dump(mode='json'), gx_policy=servicePolicy,
                          gx_termsAndConditions=gxTC.model_dump(mode='json'),
                          gx_openAPI=dataresource.openAPIURL,
                          gx_dataAccountExport=listDAE, id=serviceAccessPointURL)
    so = ServiceOfferingSAP(context=cxtList, type="VerifiableCredential", id=serviceAccessPointURL, issuer=didId,
                          issuanceDate=getCurrentDateTimeInISO(), credentialSubject=cs)


    logger.debug(f"Service access point SD={so.model_dump(by_alias=True)}")

    return so



def generate_service_offering_with_resources(body:DataProductResourcesModel,compliance:bool):

    """
          Generate a DataProduct with resources
          :param body: complete body for creating a complete Data Product Self-description
          :param compliance: true/false if the self-description is going to be checked against compliance API
          :return: JSON that presents a Data Producut self description
          :rtype: str

       """


    #Check if dataproduct exists before
    if not checkDataProduct(body.dataProductName):


        logger.debug("generate_service_offering_with_resources init")

        claims = []
        str_uuid=uuid.uuid4()
        didId = "did:web:" + str(body.domain)

        curr_time = round(time.time() * 1000)
        #Get participant VP self-description to be included in the final VP
        logger.debug(f"Requesting particiant URL={body.participantURL}")


        participantSD=requests.request("get",body.participantURL).json()


        serviceOfferingId = os.getenv("PROTOCOL") + str(body.domain) + str(os.getenv("FOLDER")) + os.getenv("DATAPRODUCT")+str("_")+str(curr_time) + str(
            os.getenv("FILE_END"))

        logger.debug(f"ServiceOffering Id={serviceOfferingId}")

        if len(body.dataResources) >0:

            logger.debug("body.dataResources>0")
            logger.debug (f"body.dataresources={body.dataResources}")
            index=0
            dataAggregation=[]
            lstAggregation = []
            for dataresource in body.dataResources:
                logger.debug("dataresource:")
                logger.debug (dataresource)
                #generate DataResource self-description and sign it

                if dataresource.serviceAccessPointInfo is not None and dataresource.dataResourceInfo is not None:
                    logger.debug("DdataresourceInfo and serviceAccessPoint is not None:")
                    # generate service Access Point Service Offering and sign it
                    if dataresource.serviceAccessPointInfo is not None:

                        logger.debug("Generate service access point self-description")
                        serviceAccessPointURL = os.getenv("PROTOCOL") + str(body.domain) + str(
                            os.getenv("FOLDER")) + os.getenv("SERVICE_ACCESS_POINT") + str(index) + str("_") + str(curr_time) + str(

                            os.getenv("FILE_END"))
                        logger.debug(f"ServiceAccessPointURL={serviceAccessPointURL}")
                        #generate a ServiceOffering similar to serviceAccessPoint
                        serviceAccessPointSD = generateServiceAccessPointService(dataresource.serviceAccessPointInfo,serviceAccessPointURL, didId,body.participantURL,body.dataProductPolicy,body.dataProductTC, body.dataAccount)

                        logger.debug(f"ServiceAccessPointSD={serviceAccessPointSD.model_dump(by_alias=True)}")

                        datafileName = os.getenv("SERVICE_ACCESS_POINT") + str(index) + str("_")+str(curr_time)+ str(".json")
                        fileNamePath = os.getenv("GAIAX_SD_FOLDER") + datafileName

                        claim=signClaim(compliance,fileNamePath,body.domain,serviceAccessPointSD.model_dump(by_alias=True))
                        claims.append(claim)

                    #generate dataResource self-description
                    if dataresource.dataResourceInfo:
                        logger.debug("Generate dataresource self-description")
                        dataresourceURL= os.getenv("PROTOCOL") + str(body.domain) + str(os.getenv("FOLDER")) +os.getenv("DATARESOURCE")+str(index) + str("_")+str(curr_time)+str(os.getenv("FILE_END"))

                        logger.debug(f"DataresourceURL={dataresourceURL}")
                        dataAggregation.append(dataresourceURL)
                        dataResourceSD=generateDataresourcesSelfDescription(serviceAccessPointURL,dataresourceURL,dataresource.dataResourceInfo,didId,body.participantURL,body.dataProductPolicy)

                        logger.debug(f"DataResourceSD={dataResourceSD.model_dump(by_alias=True)}")

                        datafileName = os.getenv("DATARESOURCE") + str(index) + str("_")+str(curr_time)+ str(".json")
                        fileNamePath = os.getenv("GAIAX_SD_FOLDER") + datafileName

                        claim = signClaim(compliance, fileNamePath, body.domain, dataResourceSD.model_dump(by_alias=True))
                        claims.append(claim)

                    index=index+1
                else:
                    logger.debug("No serviceAccessPoint or dataResource information provided")

                    return ("Error: No serviceAccessPoint or dataResource information provided")



            #generate DataProduct including DataResource that it is included in dataAggregation list


            gxTC = GxTermsAndConditions(gx_URL=body.dataProductTC, gx_hash=encrypt_string(body.dataProductTC))
            listDAE = generateDataAccountExport(body.dataAccount)
            # logger.debug(listDAE)

            provided = GxProvidedBy(id=body.participantURL)

            lstAggregation = []
            for data in dataAggregation:
                # logger.debug (data)
                aggregItem = GxAggregationOfItem(id=data)
                lstAggregation.append(aggregItem)
                # aggregation.append({"@id": data})

            logger.debug("Generate service offering SD")
            cxtList = getContextList()
            cs = CredentialSubjectSO(gx_name=body.dataProductName, gx_description=body.dataProductDesc,
                                     type="gx:ServiceOffering",
                                     gx_providedBy=provided.model_dump(mode='json'), gx_policy=body.dataProductPolicy,
                                     gx_termsAndConditions=gxTC.model_dump(mode='json'), gx_dataAccountExport=listDAE,
                                     id=serviceOfferingId, gx_aggregationOf=lstAggregation)

            so = ServiceOffering(context=cxtList, type="VerifiableCredential", id=serviceOfferingId, issuer=didId,
                                   issuanceDate=getCurrentDateTimeInISO(), credentialSubject=cs)
            logger.debug(f"ServiceOffering SD={so.model_dump(by_alias=True)}")

            #save DataProduct in a json file



            fileNamePath = os.getenv("GAIAX_SD_FOLDER") + os.getenv("DATAPRODUCT")+ str("_") + str(curr_time) +str(os.getenv("FILE_END"))

            claim = signClaim(compliance, fileNamePath, body.domain, so.model_dump(by_alias=True))
            claims.append(claim)


            #push legalParticipant VP to DataProduct VP
            logger.debug(f"Pushing participant SD to other claims")
            sd = pushVcToParticipant(participantSD, claims)
            logger.debug(f"Pushed participant SD to other claims")


            fileNamePath = os.getenv("GAIAX_SD_FOLDER") + os.getenv("DATAPRODUCT") +str("_") + str(curr_time) + str(os.getenv("FILE_END"))


            #save the final DataProduct VP as a json file
            with open(fileNamePath, "w") as f:
                json.dump(sd, f)


            #Insert dataproduct created into the database
            insertDatProduct(body.dataProductName)


            return sd
        else:
            return "No dataresources information provided"
    else:
        return "There is a data product created with the same name"
def createVpParticipant(claims: []):
    """
          Generate a Verifiable Presentation from a list of Verifiable Credentials
          :param claims: list of verifiable credentials
          :return: JSON that presents a complete Verifiable Presentation (VP) that includes "n" Verifiable credentials (VCs)
          :rtype: str

       """

    logger.debug("createVpParticipant init")

    veriCred = []
    for str in claims:

        veriCred.append(str)

    body = {
        "@context": "https://www.w3.org/ns/credentials/v2",
        "type": "VerifiablePresentation",
        "verifiableCredential":  veriCred
    }
    return body

def pushVcToParticipant(participantVC:dict, claims: []):

    """
          Push a Verifiable Credential
          :param participantVC: participant verifiable credential
          :param claims: list of verifiable credentials
          :return: JSON that presents a complete Verifiable Presentation (VP) that includes "n" Verifiable credentials (VCs)
          :rtype: str

       """

    logger.debug("pushVcToParticipant init")
    for str in claims:
        participantVC["verifiableCredential"].append(str)

    return participantVC


def encrypt_string(hash_string):
    """
          Encript a string using sha256 algorithm
          :param hash_string: string to be encrypted
          :return: encrypted string
          :rtype: str

    """


    logger.debug("encrypt_string init")
    sha_signature = hashlib.sha256(hash_string.encode()).hexdigest()
    return sha_signature


def getContextList():
    """
          Generated a context list
          :return: an array of contexts
          :rtype: str

    """

    logger.debug("getContextList init")
    cxtList=[]
    cxtList.append(os.getenv("CONTEXT_ITEM1"))
    cxtList.append(os.getenv("CONTEXT_ITEM2"))
    cxtList.append(os.getenv("CONTEXT_ITEM3"))

    return cxtList



def createDidDocument(domain:str):


    """
          Generated a did document
          :param domain: domain for the did document
          :return: did document in json format
          :rtype: str

    """


    logger.debug("createDidDocument init")

    try:
        if (domain) is None:  # The variable
            logger.debug('You must set value for domain')
    except NameError:
        logger.debug("This variable is not defined")
    else:
        if isValidDomain(domain):
            logger.info("generareDid init")
            diddoc = generateDid(domain)
            logger.info("generareDid end")
            return diddoc
        else:
            return "Domain format is not correct"


def createLegalParticipantVerifiablePresentation (body:LegalParticipantBodyModel):


    """
          Create a Legal participant verifiable presentation
          :param body: complete legal participant body model
          :return: Verifiable presentation for the Legal Participant
          :rtype: str

    """


    logger.debug("createLegalParticipantVerifiablePresentation init")

    try:
        if (body.domain or body.legalName or body.headquarterAddress or body.legalAddress or body.legalRegistrationType or body.legalRegistrationType or body.legalRegistrationNumber) is None:  # The variable
            logger.debug('You must set value for all input parameters')
    except NameError:
        logger.debug("This variables are not defined")
    else:
        #Generate Legal Person

        if isValidDomain(body.domain) and isValidURL(body.participantURL):
            logger.debug("Domain anad participantURL are valid")
            if checkISOCode(body.legalAddress) and checkISOCode(body.headquarterAddress):
                if not (body.legalRegistrationType=='vatID' or body.legalRegistrationType=='leiCode' or body.legalRegistrationType=='EORI'):
                    logger.debug('Please introduce a valid value for legalRegistrationType (vatID, leiCode or EORI)')
                    return "Please introduce a valid value for legalRegistrationType (vatID, leiCode or EORI)"
                else:
                    try:
                        logger.debug("Generating CompleteLegalPerson")
                        selfDescription=generateCompleteLegalPerson(body,True)
                        logger.debug("Generated complete legal person")
                        return selfDescription
                    except:
                        return "An error happen during legal participant generation self-description"

            else:
                return "Please introduce a correct value for legalAddress or headquarterAddres, visit https://en.wikipedia.org/wiki/ISO_3166-2"

        else:
            return "Parameter format error: please check Domain, participantURL or privateKeyURL input parameters"


def createDataProductWithResourcesVerifiablePresentation(body):


    """
          Create a Data product with resources verifiable presentation
          :param body: complete legal participant body model
          :return: Verifiable presentation for the Data Product
          :rtype: str

    """


    logger.debug (isValidDomain(body.domain))
    logger.debug(isCompleteValidURL(body.participantURL))
    if isValidDomain(body.domain) and isCompleteValidURL(body.participantURL) and isCompleteValidURL(body.dataProductTC):
        try:
            response = generate_service_offering_with_resources(body, True)
            #logger.debug (response)

            return response


        except:
            return "An error happen during service offering generation self-description"

    else:
        return "Parameter format error: please check Domain, participantURL or privateKeyURL input parameters"

def createAndPublishDataProductWithResourcesVerifiablePresentation(body):
    """
          Create and publish in CES registry a Data product with resources verifiable presentation
          :param body: complete legal participant body model
          :return: Verifiable presentation for the Data Product
          :rtype: str

    """
    logger.debug(os.getenv("CES_CHECK"))
    if (os.getenv("CES_CHECK") == "False"):
        logger.debug("CES no activated")
        logger.debug("False")

    if isValidDomain(body.domain) and isCompleteValidURL(body.participantURL) and isCompleteValidURL(
            body.dataProductTC):

        response = generate_service_offering_with_resources(body, True)
        try:
            resp = json.dumps(response)
        except:
            return logger.error("An error has happened during data product generation process")
        try:
            resCompl = callCompliance(resp)
            if resCompl is not None:
                try:
                    neo4jResult = loadInNeo4j(body.dataProductName, response)
                except:
                    return logger.error("An error during neo4j data product uploading process")
                try:
                    # CESresult="https://ces-development.lab.gaia-x.eu/credentials-events/b6f8f0ca-9a82-44d1-99b6-10f5a0cd52d3"
                    logger.debug("Neo4jResult::")
                    logger.debug(neo4jResult)
                    logger.debug("CES Check::")
                    logger.debug(os.getenv("CES_CHECK"))
                    if neo4jResult:
                        if os.getenv("CES_CHECK") == "True":
                            logger.debug("CES_CHECK is True")
                            cesID = callCredentialsEventService(resCompl)
                            logger.debug("CESRESULT___________::")
                            logger.debug(cesID)
                            if cesID is not None:
                                # cesID=CESresult.headers["location"]
                                # insertData(cesID, response, resCompl)
                                logger.debug("Inserting data starting")
                                insertData(cesID, response, resCompl)
                                logger.debug(
                                    f"A data product has been created an published at CES with the following URL={cesID}")
                                return "A data product has been created an published at CES with the following URL:: " + cesID
                            else:
                                logger.error("Data product has been generated correctly but CES service returns an error")
                                return "Data product has been generated correctly but CES service returns an error"
                        else:
                            logger.debug ("Data product has been generated correctly but it has not beer registered in CES")
                            return "Data product has been generated correctly but it has not beer registered in CES"

                    else:
                        logger.error("Data product exists and it has not been registered in CES")
                        return "Data product exists and it has not been registered in CES"
                except:
                    logger.error("CES service return an error")
                    return "CES service return an error"
            else:
                logger.error("An error has happened during Compliance service call process")
                return "An error has happened during Compliance service call process"

        except:
            logger.error("An error has happened during Compliance service call process")
            return "An error has happened during Compliance service call process"
        # loadInNeo4j






    else:
        logger.error("Parameter format error: please check Domain, participantURL or privateKeyURL input parameters")
        return ("Parameter format error: please check Domain, participantURL or privateKeyURL input parameters")




def signClaim (compliance:bool,fileNamePath:str,domain:str, claim:dict):

    """
          sign claim
          :param compliance: true/false paramater
          :param fileNamePath: path to be saved the signed claim
          :param domain: domain used
          :param claim: claim to be signed
          :return: a signed claim
          :rtype: str

    """


    logger.debug("signClaim() init")
    if compliance == True:
        didId = os.getenv("DID") + str(domain)
        claim = sign_doc(claim, str(didId) + os.getenv("ISSUER_KEY"))
        logger.debug(claim)
        with open(fileNamePath, "w") as f:
            json.dump(claim, f)
    else:

        with open(fileNamePath, "w") as f:
            json.dump(claim, f)
    logger.debug("signClaim() end")
    return claim