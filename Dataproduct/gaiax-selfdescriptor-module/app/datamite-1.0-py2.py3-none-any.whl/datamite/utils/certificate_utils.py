"""
MIT License

Copyright (c) 2024 Tecnalia, Basque Research & Technology Alliance (BRTA)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""





"""This module give the functionality to work with certificates.
"""
import logging
import os
import sys
from hashlib import sha1
from hashlib import sha256

import requests
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from jwcrypto import jwk, jws
from jwcrypto.common import json_encode
from pyld import jsonld


logger = logging.getLogger("uvicorn.error")

def get_infoFromURL(url):
    """
       Get information given an  URL

       :param url: url to be downloaded information.
       :return: complete text from the response.
       :rtype: json/text
    """

    logger.debug("requesting to specified url")
    response = requests.request("GET", url)

    if response.status_code == 200:
        return response.text
    elif response.status_code == 404:
        return None





def generatePublicJWK(cert):

    """
       Generate Public JWK from a cert

       :param cert: X.509 certificate.
       :return: return a public key
       :rtype: str
    """

    logger.debug("init")

    def print_value(description, cert, nameOID):
        attributes = cert.subject.get_attributes_for_oid(nameOID)
        logger.debug(f"%s: " % description, ",".join([attr.value for attr in attributes]))


    """print_value("Company number", cert, x509.oid.NameOID.SERIAL_NUMBER)
    print_value("Country name", cert, x509.oid.NameOID.COUNTRY_NAME)
    print_value("Country name", cert, x509.oid.NameOID.STATE_OR_PROVINCE_NAME)
    print_value("Country name", cert, x509.oid.NameOID.LOCALITY_NAME)"""

    publickey = jwk.JWK.from_pem(cert.public_key().public_bytes(
        encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo))
    logger.debug("publickey:%s" %publickey)



    return publickey

def locate_certificate():

    """
       Locate a certificate
       :return: return a X.509 cert

    """

    logger.debug("getting information from the certificate")
    cert = get_infoFromURL(os.getenv("CERTIFICATE_URL"))
    logger.debug("recovered information from the certificate")
    #cert=os.getenv("CERTIFICATE")
    certInBytes = bytes(cert, 'UTF-8')
    rawcerts = x509.load_pem_x509_certificates(certInBytes)

    logger.debug("getting rawcerts from the certificate")

    for cert in rawcerts:
        logger.debug(f"Serial Number={hex(cert.serial_number)}")
        logger.debug(f"Fingerlogger.debug={cert.fingerprint(cert.signature_hash_algorithm).hex()}")
        logger.debug(f"Thumblogger.debug={sha1(cert.public_bytes(serialization.Encoding.DER)).hexdigest()}")
        logger.debug(f"Issuer={cert.issuer}")
        logger.debug(f"Subject={cert.subject}")
        subject = cert.extensions.get_extension_for_class(x509.SubjectKeyIdentifier)
        logger.debug(f"SubjectID={subject.value.key_identifier.hex()}")
        try:
            authority = cert.extensions.get_extension_for_class(x509.AuthorityKeyIdentifier)
            logger.debug(f"AuthID={authority.value.key_identifier.hex()}")
        except x509.ExtensionNotFound:
            pass
        #    for ext in cert.extensions:
        #        logger.debug(ext.oid, ext.value)


    for cert in rawcerts:
        try:
            ext = cert.extensions.get_extension_for_oid(x509.oid.ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
            dnsNames = ext.value.get_values_for_type(x509.DNSName)
            logger.debug("Found dnsNames {} for cert {}.".format(dnsNames, cert.subject))
            break
        except x509.ExtensionNotFound:
            pass
    logger.debug("returning cert")
    return cert

def sign_doc(doc, issuerKey):

    """
       Giving an issuerKey and a json document sign it

       :param doc: document to be signed.
       :param issuerKey: issuerKey to be included in a signed document
       :return: return a signed document
       :rtype: str
    """

    try:
        logger.debug ("Signing doc")
        privkeyStr = os.getenv("PRIVATE_KEY")
        if privkeyStr is not None:
            logger.debug("Private key is not None")
            privkeyBytes = bytes(privkeyStr, 'UTF-8')


            privkey = jwk.JWK()
            privkey.import_from_pem(privkeyBytes, password=None)

            normalized = jsonld.normalize(doc, {'algorithm': 'URDNA2015', 'format': 'application/n-quads'})
            logger.debug(f"Normalized= {normalized}")
            hash = sha256(normalized.encode('utf-8'))

            jwstoken = jws.JWS(hash.hexdigest())
            jwstoken.add_signature(privkey, None,
                                   json_encode({"alg": "PS256", "b64": False, "crit" :["b64"]}))

            signed = jwstoken.serialize(compact=True)

            doc['proof'] = {
                "type": "JsonWebSignature2020",
                "proofPurpose": "assertionMethod",
                "verificationMethod": issuerKey,
                "jws": compact_token(signed)
            }
            logger.debug(f"returned doc= {doc}")
            return doc
        else:
            return None
    except:
         sys.exit("Error during signing process")



def signVeriablePresentation(verifiablePresentation: dict, domain: str):

    """
       Sign a Verifiable Presentation

       :param verifiablePresentation: verifiablePresentation to be signed.
       :param domain: issuerKey to be included in a signed document
       :return: return a signed document
       :rtype: str
    """



    didId = os.getenv("DID") + str(domain)

    logger.debug(f"data={verifiablePresentation.get('verifiableCredential')}")
    claims = []
    for vc in verifiablePresentation.get("verifiableCredential"):
        claims.append(sign_doc(vc, str(didId) + os.getenv("ISSUER_KEY")))
    del verifiablePresentation["verifiableCredential"]

    verifiablePresentation["verifiableCredential"] = claims
    logger.debug("end in signVeriablePresentation method")
    return verifiablePresentation



def compact_token(token):

    """
       Compact token

       :param token: token to be compacted
       :return: return a compacted token

    """
    logger.debug("init")
    parts = token.split(".")
    logger.debug("end")
    return parts[0] + ".." + parts[2]




