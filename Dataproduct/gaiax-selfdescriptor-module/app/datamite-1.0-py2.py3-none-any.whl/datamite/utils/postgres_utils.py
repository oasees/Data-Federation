"""
MIT License

Copyright (c) 2024 Tecnalia, Basque Research & Technology Alliance (BRTA)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


"""This module give the functionality to work with Postgres SQL Database
"""

import json
import logging
import os

import psycopg2 as psycopg2

logger = logging.getLogger("uvicorn.error")

def connectPostgres():
    """
       Connect to a Postgres database

       :return: return postgres connection

    """

    logger.debug("init")
    conn = psycopg2.connect(database=os.getenv("POSTGRES_DB"),
                            user=os.getenv("POSTGRES_USER"),
                            host=os.getenv("POSTGRES_HOST"),
                            password=os.getenv("POSTGRES_PASSWORD"),
                            port=os.getenv("POSTGRES_PORT"))
    logger.debug("end")
    return conn



def insertData(cesID:str, dataProductData:dict, cesData:dict):

    """
       Insert data in CES postgres table

       :param cesID: cesID to be loaded
       :param dataProductData: json document describing data product
       :param cesData: json document describing credential event service data
       :return: a new record into ces table if not exist

    """

    logger.debug("inserting data")
    conn = connectPostgres()
    cur = conn.cursor()
    #cur.execute("INSERT INTO ces(ces_id,ces_data VALUES("'cesID','cesData'")")
    #cur.execute("INSERT INTO ces(ces_id, ces_data VALUES (%s, %s)", [cesID], [cesData])
    try:

        sql = "INSERT INTO ces (ces_id, dataproduct_json,compliance_json) VALUES (%s, %s, %s)"
        logger.debug(f"insertData():sql={sql}")

        val = (cesID, json.dumps(dataProductData),json.dumps(cesData))
        cur.execute(sql, val)

        conn.commit()

    except:
        logger.error("ced_id exists")
        cur.close()
        #conn.close()

def getCesData():

    """
       Get information from CES table

       :return: give a list of ces records
       :rtype : str

    """


    logger.debug("init")
    conn = connectPostgres()
    cur = conn.cursor()
    postgreSQL_select_Query = "select * from ces"

    cur.execute(postgreSQL_select_Query)
    logger.debug("Selecting rows from mobile table using cursor.fetchall")
    """ces_records = cur.fetchall()
    for row in ces_records:
        logger.debug("ces_id = ", row[0])
    """


    columns = [column[0] for column in cur.description]
    data = [dict(zip(columns, row)) for row in cur.fetchall()]
    logger.debug (data)
    return data



def checkDataProduct( dataproductName:str):
    """
         Check dataproduct in dp postgres table

         :param dataProductName: dataProductName to be checked
         :return: True if data product exists

      """


    logger.debug("checkDataProduct")
    conn = connectPostgres()
    cur = conn.cursor()
    try:

        sql = "SELECT dataproductname FROM dp WHERE dataproductname= '"+dataproductName+"'"
        logger.debug(f"check data product name():sql={sql}")
        cur.execute(sql)
        records = cur.fetchall()
        if len(records) > 0:
            return True

    except:
        logger.error("Error checking data product")
        cur.close()
        return False
        #conn.close()



def insertDatProduct(dataProductName:str):

    """
       Insert dataproduct in dp postgres table

       :param dataProductName: dataProductName to be loaded
       :return: a new record into dp table if not exist

    """



    logger.debug("inserting data")
    conn = connectPostgres()
    cur = conn.cursor()

    try:



        sql = "INSERT INTO public.dp (dataproductname) VALUES (%s)"

        logger.debug(f"insertData():sql={sql}")

        record_to_insert = (dataProductName,)
        cur.execute(sql, record_to_insert)



        conn.commit()
        count = cur.rowcount
        print(count, "Record inserted successfully into mobile table")


    except Exception as error:
        print (error)
        logger.error("ced_id exists")
        cur.close()
        #conn.close()
