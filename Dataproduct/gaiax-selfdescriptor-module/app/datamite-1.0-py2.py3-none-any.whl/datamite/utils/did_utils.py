"""
MIT License

Copyright (c) 2024 Tecnalia, Basque Research & Technology Alliance (BRTA)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""



"""This module give the functionality to work with did documents.
"""

import json
import logging
import os
import sys
from base64 import urlsafe_b64encode
from hashlib import sha1

from cryptography.hazmat.primitives import serialization

from datamite.models.didModel import PublicKeyJwk, VerificationMethodItem, DidModel
from datamite.utils.certificate_utils import generatePublicJWK
from datamite.utils.certificate_utils import locate_certificate

logger = logging.getLogger("uvicorn.error")





def generateDid(domain: str):


    """
       Generate a did document

       :param domain: domain
       :return: return a did document
       :rtype: str
    """

    logger.debug("generateDid::")

    logger.debug(f'domain={domain}')

    #locate certificate
    logger.debug("locate_certificate init")
    cert = locate_certificate()
    logger.debug("locate_certificate end")


    didId = os.getenv("DID") + str(domain)

    logger.debug(f'didId={didId}')

    #generate PublicJWK from cert
    logger.debug("generating PublicJWK")

    publicKeyJwk = generatePublicJWK(cert)
    thumbprint = sha1(cert.public_bytes(serialization.Encoding.DER))
    publicKeyJwkJson = json.loads(publicKeyJwk.export())
    publicKeyJwkJson["x5u"]= os.getenv("CERTIFICATE_URL")
    publicKeyJwkJson["x5t"] = urlsafe_b64encode(thumbprint.digest()).rstrip(b'=').decode('utf-8')
    publicKeyJwkJson["alg"] = os.getenv("RSA_ALGO")

    pk=PublicKeyJwk(e=publicKeyJwkJson.get("e"),kid=publicKeyJwkJson.get("kid"),kty=publicKeyJwkJson.get("kty"),n=publicKeyJwkJson.get("n"), x5u=publicKeyJwkJson.get("x5u"), x5t=publicKeyJwkJson.get("x5t"),alg=publicKeyJwkJson.get("alg"))

    #create Verification Item using didId, and publicKey information

    logger.debug("generating verification method item")
    vm=VerificationMethodItem(id=didId + str(os.getenv("ISSUER_KEY")),type="JsonWebKey2020",controller=didId,publicKeyJwk=pk)


    #fill assertionMethod list
    logger.debug("filling assertion method list")
    assertionMethodList=[]
    assertionMethodList.append(didId + str(os.getenv("ISSUER_KEY")))

    #fill verificationMethod list
    verifationMethodlist=[]
    verifationMethodlist.append(vm)
    logger.debug("verification method append")

    #fill context items array
    cxt=[]
    cxt.append("https://www.w3.org/ns/did/v1")
    cxt.append("https://w3id.org/security/suites/jws-2020/v1")

    #fill did Model using context, didId, verificationMethodList and assertionMethodList

    logger.debug("generating did Model")
    did=DidModel(context=cxt,id=didId,verificationMethod=verifationMethodlist,assertionMethod=assertionMethodList)

    #create did.json file cform didModel
    logger.debug("saving did model into a did.json")
    fileNamePath = os.getenv("GAIAX_SD_FOLDER") + str("did.json")
    with open(fileNamePath, "w") as f:
        json.dump(did.model_dump(by_alias=True), f)

    #return did as json
    logger.debug("generated did.json content::%s"  %did.model_dump(by_alias=True))
    return did.model_dump(by_alias=True)